-- SQL Server Sample Schema for Sales Database
CREATE TABLE customers (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100),
    created_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE products (
    product_id INT IDENTITY(1,1) PRIMARY KEY,
    product_name NVARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE orders (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT FOREIGN KEY REFERENCES customers(customer_id),
    order_date DATE NOT NULL DEFAULT GETDATE()
);

CREATE TABLE order_items (
    order_item_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT FOREIGN KEY REFERENCES orders(order_id),
    product_id INT FOREIGN KEY REFERENCES products(product_id),
    quantity INT NOT NULL
);

-- Sample Data Insert
INSERT INTO customers (customer_name, email) VALUES
('Alice Johnson', 'alice@example.com'),
('Bob Smith', 'bob@example.com');

INSERT INTO products (product_name, price) VALUES
('Laptop', 1200.00),
('Mouse', 25.50);

INSERT INTO orders (customer_id, order_date) VALUES
(1, '2024-01-15'),
(2, '2024-01-17');

INSERT INTO order_items (order_id, product_id, quantity) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 2, 1);

-- Common Queries
-- 1. Select customers with their orders and total amount
SELECT c.customer_name, o.order_id, SUM(oi.quantity * p.price) AS total_amount
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
GROUP BY c.customer_name, o.order_id
ORDER BY total_amount DESC;

-- 2. Create a stored procedure to get total spent by customer
CREATE PROCEDURE dbo.GetCustomerTotal
    @CustomerId INT,
    @TotalSpent DECIMAL(18,2) OUTPUT
AS
BEGIN
    SELECT @TotalSpent = SUM(oi.quantity * p.price)
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    WHERE o.customer_id = @CustomerId;

    SET @TotalSpent = ISNULL(@TotalSpent, 0);
END;

-- Usage: EXEC dbo.GetCustomerTotal @CustomerId = 1, @TotalSpent = @total OUTPUT;